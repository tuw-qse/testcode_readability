

    @Test
	@Timeout(4000)
	public void test10() throws Throwable {
		MultiBackgroundInitializer multiBackgroundInitializer0 = new MultiBackgroundInitializer();
		assertNotNull(multiBackgroundInitializer0);
		assertFalse(multiBackgroundInitializer0.isStarted());

		MultiBackgroundInitializer.MultiBackgroundInitializerResults
				multiBackgroundInitializer_MultiBackgroundInitializerResults0 = multiBackgroundInitializer0
				.initialize();
		assertNotNull(multiBackgroundInitializer_MultiBackgroundInitializerResults0);
		assertFalse(multiBackgroundInitializer0.isStarted());
		assertTrue(multiBackgroundInitializer_MultiBackgroundInitializerResults0.isSuccessful());

		boolean boolean0 = multiBackgroundInitializer0.start();
		assertTrue(multiBackgroundInitializer0.isStarted());
		assertTrue(boolean0);

		// Undeclared exception!
		try {
			multiBackgroundInitializer0.addInitializer(".wXhIU/C,V", (BackgroundInitializer<?>) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// Child initializer must not be null!
			//
			verifyException("org.apache.commons.lang3.Validate", e);
		}
	}
