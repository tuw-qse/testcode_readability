

	public static boolean debug = false;

    @Test
    public void test1113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1113");
        java.lang.CharSequence[] charSequenceArray6 = new java.lang.CharSequence[] { "hi!", "hi!" };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.prependIfMissing("", (java.lang.CharSequence) "", charSequenceArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.joinWith("", (java.lang.Object[]) charSequenceArray6);
        java.lang.CharSequence charSequence9 = org.apache.commons.lang3.StringUtils.firstNonEmpty(charSequenceArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray6, '#');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0 0 0  HI!  0 0 0 ", charSequenceArray6);
        org.junit.Assert.assertNotNull(charSequenceArray6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "hi!hi!" + "'", str8, "hi!hi!");
        org.junit.Assert.assertEquals("'" + charSequence9 + "' != '" + "hi!" + "'", charSequence9, "hi!");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "hi!#hi!" + "'", str11, "hi!#hi!");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }
