

private static final int SKIP = 500;

    @ParameterizedTest
    @MethodSource("fractionParameters")
    public void testReducedFraction(int i, int j) {
        Fraction f = Fraction.getFraction((double) j / (double) i);
        Fraction f2 = Fraction.getReducedFraction(j, i);
        assertEquals(f2.getNumerator(), f.getNumerator());
        assertEquals(f2.getDenominator(), f.getDenominator());
    }

    private static Stream<Arguments> fractionParameters() {
        // save time by skipping some tests!
        return Stream.iterate(1, i -> i + SKIP)
                .limit(10000 / SKIP)
                .flatMap(denominator -> IntStream.rangeClosed(1, denominator)
                        .mapToObj(numerator -> arguments(denominator, numerator)));
    }
