

    @Test
    public void testNextOnBuffer_shouldReturnNextElement(){
        RingBuffer<String> ringBuffer = new RingBuffer<>(2);

        ringBuffer.enqueue("a");
        ringBuffer.enqueue("b");

        assertEquals("a", ringBuffer.iterator().next());
    }

    @Test
    public void testSizeWhenBeyondCapacity_shouldEqualNumberOfElements(){
        RingBuffer<String> ringBuffer = new RingBuffer<>(2);

        ringBuffer.enqueue("a");
        ringBuffer.enqueue("b");
        ringBuffer.enqueue("c");

        assertEquals(2, ringBuffer.size());
    }
