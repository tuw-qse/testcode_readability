

    @DefaultLocale(language = "de", country = "DE")
	@Test
	public void testContainsIgnoreCase_LocaleIndependence() {
		Locale.setDefault(Locale.ENGLISH);
		assertTrue(StringUtils.containsIgnoreCase("i", "I"));
		assertTrue(StringUtils.containsIgnoreCase("I", "i"));
		assertTrue(StringUtils.containsIgnoreCase("\u03C2", "\u03C3"));
		assertTrue(StringUtils.containsIgnoreCase("\u03A3", "\u03C2"));
		assertTrue(StringUtils.containsIgnoreCase("\u03A3", "\u03C3"));
        assertFalse(StringUtils.containsIgnoreCase("\u00DF", "SS"));

		Locale.setDefault(new Locale("tr"));
		assertTrue(StringUtils.containsIgnoreCase("i", "I"));
		assertTrue(StringUtils.containsIgnoreCase("I", "i"));
		assertTrue(StringUtils.containsIgnoreCase("\u03C2", "\u03C3"));
		assertTrue(StringUtils.containsIgnoreCase("\u03A3", "\u03C2"));
		assertTrue(StringUtils.containsIgnoreCase("\u03A3", "\u03C3"));
        assertFalse(StringUtils.containsIgnoreCase("\u00DF", "SS"));
        
		Locale.setDefault(Locale.getDefault());
		assertTrue(StringUtils.containsIgnoreCase("i", "I"));
		assertTrue(StringUtils.containsIgnoreCase("I", "i"));
		assertTrue(StringUtils.containsIgnoreCase("\u03C2", "\u03C3"));
		assertTrue(StringUtils.containsIgnoreCase("\u03A3", "\u03C2"));
		assertTrue(StringUtils.containsIgnoreCase("\u03A3", "\u03C3"));
        assertFalse(StringUtils.containsIgnoreCase("\u00DF", "SS"));
	}  
