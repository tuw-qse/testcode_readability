

    @Test
    public void test1113() throws Throwable {
        CharSequence[] charSequenceArray6 = new CharSequence[] { "hi!", "hi!" };
        assertNotNull(charSequenceArray6);
        assertEquals("", StringUtils.prependIfMissing("", (CharSequence) "", charSequenceArray6));
        assertEquals("hi!hi!", StringUtils.joinWith("", (Object[]) charSequenceArray6));
        assertEquals("hi!", StringUtils.firstNonEmpty(charSequenceArray6));
        assertEquals("hi!#hi!", StringUtils.join((Object[]) charSequenceArray6, '#'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) "0 0 0  HI!  0 0 0 ", charSequenceArray6));
    }
