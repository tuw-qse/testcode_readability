

    @Test
    public void testDequeue_firstElementIsDeleted() {
        RingBuffer<String> buffer = new RingBuffer(3);
        buffer.enqueue("A");
        buffer.enqueue("B");
        buffer.enqueue("C");

        assertEquals("A", buffer.dequeue(), "should return the first added element");
        assertEquals(2, buffer.size(), "size should decrease due to deletion");
        assertEquals("B", buffer.peek(), "first element should have changed due to deletion");
    }

    @Test
    public void testDequeue_emptyBuffer_shouldThrowRuntimeException() {
        RingBuffer<String> buffer = new RingBuffer(5);
        assertThrows(RuntimeException.class, () -> {
            buffer.dequeue();
        });
    }

    @Test
    public void testPeek_firstElementIsReturned() {
        RingBuffer<String> buffer = new RingBuffer(3);
        buffer.enqueue("A");
        buffer.enqueue("B");
        buffer.enqueue("C");

        assertEquals("A", buffer.peek(), "should return the first added element");
    }

    @Test
    public void testEnqueue_bufferIsFull_firstElementIsOverridden() {
        RingBuffer<String> buffer = new RingBuffer(3);
        buffer.enqueue("A");
        buffer.enqueue("B");
        buffer.enqueue("C");
        assertEquals("A", buffer.peek(), "should return the first added element");

        buffer.enqueue("D");
        assertEquals("B", buffer.peek(), "the first element should be overwritten");
    }
