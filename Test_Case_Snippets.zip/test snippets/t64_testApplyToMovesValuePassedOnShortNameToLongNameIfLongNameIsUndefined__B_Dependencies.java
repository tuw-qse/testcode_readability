

    @Test
    public void testApplyToMovesValuePassedOnShortNameToLongNameIfLongNameIsUndefined() throws RequiredParametersException{
        ParameterTool parameter = ParameterTool.fromArgs(new String[] {"--b", "value"});
        RequiredParameters required = new RequiredParameters();

        required.add(new Option("berlin").alt("b"));
        parameter = required.applyTo(parameter);
        Assert.assertEquals("value", parameter.data.get("berlin"));
        Assert.assertEquals("value", parameter.data.get("b"));
    }
