

    @Test
    public void testCapacity() {
        RingBuffer<Integer> ringBuffer = new RingBuffer<>(3);
        assertEquals(3, ringBuffer.capacity());

        ringBuffer = new RingBuffer<>(1748);
        assertEquals(1748, ringBuffer.capacity());
    }

    @Test
    public void testSize_fromEmptyToFull() {
        RingBuffer<Integer> ringBuffer = new RingBuffer<>(3);
        assertEquals(0, ringBuffer.size());

        ringBuffer.enqueue(1);
        assertEquals(1, ringBuffer.size());

        ringBuffer.enqueue(2);
        assertEquals(2, ringBuffer.size());

        ringBuffer.enqueue(3);
        assertEquals(3, ringBuffer.size());
    }
