

    @Test
    public void test551() throws Throwable {
        StopWatch stopWatch1 = new StopWatch("");
        stopWatch1.reset();
        stopWatch1.reset();
        assertFalse(stopWatch1.isSuspended());
        assertEquals("00:00:00.000", stopWatch1.toString());
        assertFalse(stopWatch1.isSuspended());
        stopWatch1.start();
        stopWatch1.stop();
        assertFalse(stopWatch1.isStarted());
        assertEquals(1592683830012L, stopWatch1.getStartTime()); // flaky
    }
