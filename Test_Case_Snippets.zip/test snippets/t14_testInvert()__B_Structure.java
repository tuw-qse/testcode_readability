

	@Test
	public void testInvert() {
		Fraction f1 = Fraction.getFraction(50, 75);
		f1 = f1.invert();
		assertEquals(75, f1.getNumerator());
		assertEquals(50, f1.getDenominator());

		Fraction f2 = Fraction.getFraction(4, 3);
		f2 = f2.invert();
		assertEquals(3, f2.getNumerator());
		assertEquals(4, f2.getDenominator());

		Fraction f3 = Fraction.getFraction(-15, 47);
		f3 = f3.invert();
		assertEquals(-47, f3.getNumerator());
		assertEquals(15, f3.getDenominator());

		try {
			Fraction.getFraction(0, 3).invert();
			Fraction.getFraction(Integer.MIN_VALUE, 1).invert(); 
		} catch (ArithmeticException e) {
			assertEquals("Unable to invert zero.", e.getMessage());
		}

		Fraction f4 = Fraction.getFraction(Integer.MAX_VALUE, 1);
		f4 = f4.invert();
		assertEquals(1, f4.getNumerator());
		assertEquals(Integer.MAX_VALUE, f4.getDenominator());
	}
