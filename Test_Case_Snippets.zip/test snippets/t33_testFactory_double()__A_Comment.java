

	@Test
	public void testFactory_double() {
		// zero
		Fraction f = Fraction.getFraction(0.0d);
		assertEquals(0, f.getNumerator());
		assertEquals(1, f.getDenominator());

		// one
		f = Fraction.getFraction(1.0d);
		assertEquals(1, f.getNumerator());
		assertEquals(1, f.getDenominator());

		// one half
		f = Fraction.getFraction(0.5d);
		assertEquals(1, f.getNumerator());
		assertEquals(2, f.getDenominator());

		// negative
		f = Fraction.getFraction(-0.875d);
		assertEquals(-7, f.getNumerator());
		assertEquals(8, f.getDenominator());

		// over 1
		f = Fraction.getFraction(1.25d);
		assertEquals(5, f.getNumerator());
		assertEquals(4, f.getDenominator());

		// two thirds
		f = Fraction.getFraction(0.66666d);
		assertEquals(2, f.getNumerator());
		assertEquals(3, f.getDenominator());

		// small
		f = Fraction.getFraction(1.0d / 10001d);
		assertEquals(0, f.getNumerator());
		assertEquals(1, f.getDenominator());
	}
