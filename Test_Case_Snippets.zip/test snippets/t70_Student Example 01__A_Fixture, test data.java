

    private RingBuffer<String> ringBuffer = null;
    private Iterator<String> iterator = null;
    int DEFAULT_CAPACITY = 2;

    @BeforeEach
    public void initialize(){
        ringBuffer = new RingBuffer<>(DEFAULT_CAPACITY);
        iterator = ringBuffer.iterator();
    }

    @Test
    public void testNextOnBuffer_shouldReturnNextElement(){
        ringBuffer.enqueue("a");
        ringBuffer.enqueue("b");

        assertEquals("a", iterator.next());
    }

    @Test
    public void testSizeWhenBeyondCapacity_shouldEqualNumberOfElements(){
        ringBuffer.enqueue("a");
        ringBuffer.enqueue("b");
        ringBuffer.enqueue("c");

        assertEquals(DEFAULT_CAPACITY, ringBuffer.size());
    }
