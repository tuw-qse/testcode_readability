

    @Test
    public void test0074() throws Throwable {
        boolean[] booleanArray5 = Conversion.hexDigitMsb0ToBinary('a');
        assertEquals("[true, false, true, false]", Arrays.toString(booleanArray5));

        boolean[] booleanArray8 = Conversion.byteToBinary((byte) 0, (int) ' ', booleanArray5, 0, 0);
        assertEquals("[true, false, true, false]", Arrays.toString(booleanArray8));

        char char9 = Conversion.binaryToHexDigit(booleanArray8);
        assertEquals('5', char9);

        try {
            Conversion.intToBinary(-1, 0, booleanArray8, -1, 1);
            fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException e) {
        	// Expected exception message: Index -1 out of bounds for length 4
        }
    }
