

	@Test
	public void testPrimitiveTypeClassSerialization() {
		final Class<?>[] primitiveTypes = { byte.class, short.class, int.class, long.class, float.class, double.class,
				boolean.class, char.class, void.class };

		for (final Class<?> primitiveType : primitiveTypes) {
			final Class<?> clone = SerializationUtils.clone(primitiveType);
			assertEquals(primitiveType, clone);
		}
	}
