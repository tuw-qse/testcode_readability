

    @Test
    public void testFourElement2() {
        SmartList<Integer> l = new SmartList<>();
        int modCount = 0;

        l.clear();
        assertThat(l).isEmpty();
        assertThat(l.getModificationCount()).isEqualTo(++modCount);
        assertThat(l.toString()).isEqualTo("[]");

        Iterator<Integer> iterator = l.iterator();
        assertThat(iterator).isSameAs(Collections.emptyIterator());
        assertThat(iterator.hasNext()).isFalse();

        l.add(-2);
        iterator = l.iterator();
        assertThat(iterator).isNotSameAs(Collections.emptyIterator());
        assertThat(iterator.hasNext()).isTrue();
        assertThat(iterator.next()).isEqualTo(-2);
        assertThat(iterator.hasNext()).isFalse();

        assertThrows(IndexOutOfBoundsException.class, () -> l.get(1));
    }
