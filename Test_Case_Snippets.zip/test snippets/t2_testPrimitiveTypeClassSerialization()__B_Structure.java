

    @Test
	public void testPrimitiveTypeClassSerialization() {
		assertEquals(byte.class, SerializationUtils.clone(byte.class));
		assertEquals(short.class, SerializationUtils.clone(short.class));
		assertEquals(int.class, SerializationUtils.clone(int.class));
		assertEquals(long.class, SerializationUtils.clone(long.class));
		assertEquals(float.class, SerializationUtils.clone(float.class));
		assertEquals(double.class, SerializationUtils.clone(double.class));
		assertEquals(boolean.class, SerializationUtils.clone(boolean.class));
		assertEquals(char.class, SerializationUtils.clone(char.class));
		assertEquals(void.class, SerializationUtils.clone(void.class));
	}

	