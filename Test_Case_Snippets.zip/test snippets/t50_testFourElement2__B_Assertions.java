

    @Test
    public void testFourElement2() {
        SmartList<Integer> l = new SmartList<>();
        int modCount = 0;

        l.clear();
        assertTrue(l.isEmpty());
        assertEquals(++modCount, l.getModificationCount());
        assertEquals("[]", l.toString());

        Iterator<Integer> iterator = l.iterator();
        assertSame(Collections.emptyIterator(), iterator);
        assertFalse(iterator.hasNext());

        l.add(-2);
        iterator = l.iterator();
        assertNotSame(Collections.emptyIterator(), iterator);
        assertTrue(iterator.hasNext());
        assertEquals(-2, iterator.next());
        assertFalse(iterator.hasNext());

        assertThrows(IndexOutOfBoundsException.class, () -> l.get(1));
    }
