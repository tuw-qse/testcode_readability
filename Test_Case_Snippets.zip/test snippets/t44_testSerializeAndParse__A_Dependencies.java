

    @Test
    public void testSerializeAndParse() throws Exception {
        TestAllTypes.Builder builder = TestAllTypes.newBuilder();
        builder.setOptionalInt32(1234);
        builder.setOptionalString("hello");
        builder.setOptionalNestedMessage(TestAllTypes.NestedMessage.getDefaultInstance());

        ByteString data = builder.build().toByteString();
        TestAllTypes message = TestAllTypes.parseFrom(data);

        assertEquals(1234, message.getOptionalInt32());
        assertEquals("hello", message.getOptionalString());

        // Fields not set will have the default value.
        assertEquals(ByteString.EMPTY, message.getOptionalBytes());
        assertEquals(TestAllTypes.NestedEnum.FOO, message.getOptionalNestedEnum());

        // The message field is set despite that it's set with a default instance.
        assertTrue(message.hasOptionalNestedMessage());
        assertEquals(0, message.getOptionalNestedMessage().getValue());
    }
