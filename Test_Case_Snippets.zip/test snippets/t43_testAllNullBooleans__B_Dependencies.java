

    @Test
    public void testAllNullBooleans_TotalCount() {
        BooleanColumnSummary summary = summarize(null, null, null, null);
        Assert.assertEquals(4, summary.getTotalCount());
    }

    @Test
    public void testAllNullBooleans_NullCount() {
        BooleanColumnSummary summary = summarize(null, null, null, null);
        Assert.assertEquals(4, summary.getNullCount());
    }

    @Test
    public void testAllNullBooleans_NonNullCount() {
        BooleanColumnSummary summary = summarize(null, null, null, null);
        Assert.assertEquals(0, summary.getNonNullCount());
    }

    @Test
    public void testAllNullBooleans_TrueCount() {
        BooleanColumnSummary summary = summarize(null, null, null, null);
        Assert.assertEquals(0, summary.getTrueCount());
    }

    @Test
    public void testAllNullBooleans_FalseCount() {
        BooleanColumnSummary summary = summarize(null, null, null, null);
        Assert.assertEquals(0, summary.getFalseCount());
    }
