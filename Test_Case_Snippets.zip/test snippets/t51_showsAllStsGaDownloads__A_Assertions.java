

    @Test
    public void showsAllStsGaDownloads() throws Exception {
        MvcResult mvcResult = mockMvc.perform(get("/tools/sts/all"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith("text/html"))
                .andReturn();

        Document document = Jsoup.parse(mvcResult.getResponse().getContentAsString());
        assertThat(document.select("h1").text(), equalTo("Spring Tool Suite Downloads"));
        assertThat(document.select(".ga--release h2.tool-versions--version").text(), allOf(containsString("STS"),
                containsString("RELEASE")));
        assertThat(document.select(".platform h3").text(), containsString("Windows"));

        assertThat(document.select(".ga--release .item--dropdown a").attr("href"), allOf(
                containsString("http:/download.springsource.com/release/STS/"),
                containsString("spring-tool-suite"),
                containsString("win32-installer.exe")));
    }
