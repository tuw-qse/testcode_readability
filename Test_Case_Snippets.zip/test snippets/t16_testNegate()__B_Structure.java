

    @Test
	public void testNegate() {
		Fraction f1 = Fraction.getFraction(50, 75);
		f1 = f1.negate();
		assertEquals(-50, f1.getNumerator());
		assertEquals(75, f1.getDenominator());

		Fraction f2 = Fraction.getFraction(-50, 75);
		f2 = f1.negate(); 			
		assertEquals(50, f2.getNumerator());
		assertEquals(75, f2.getDenominator());

		// large values
		Fraction f3 = Fraction.getFraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
		f3 = f3.negate();
		assertEquals(Integer.MIN_VALUE + 2, f3.getNumerator());
		assertEquals(Integer.MAX_VALUE, f3.getDenominator());

		assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, 1).negate());
	}
