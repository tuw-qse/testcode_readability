

    @Test
    public void testApplyToWithMultipleTypes() throws RequiredParametersException{
        ParameterTool parameter = ParameterTool.fromArgs(new String[] {});
        RequiredParameters required = new RequiredParameters();

        required.add(new Option("berlin").defaultValue("value"));
        required.add(new Option("count").defaultValue("15"));
        required.add(new Option("someFlag").alt("sf").defaultValue("true"));

        parameter = required.applyTo(parameter);

        Assert.assertEquals("value", parameter.data.get("berlin"));
        Assert.assertEquals("15", parameter.data.get("count"));
        Assert.assertEquals("true", parameter.data.get("someFlag"));
        Assert.assertEquals("true", parameter.data.get("sf"));

    }
