

	@Test
	public void testContainsRange() {
		Range<Integer> intRange = Range.between(10, 20);

		assertFalse(intRange.containsRange(null));

		assertTrue(intRange.containsRange(Range.between(12, 18)));

		assertFalse(intRange.containsRange(Range.between(32, 45)));
		assertFalse(intRange.containsRange(Range.between(2, 8)));

		assertTrue(intRange.containsRange(Range.between(10, 20)));

		assertFalse(intRange.containsRange(Range.between(9, 14)));
		assertFalse(intRange.containsRange(Range.between(16, 21)));

		assertTrue(intRange.containsRange(Range.between(10, 19)));
		assertFalse(intRange.containsRange(Range.between(10, 21)));

		assertTrue(intRange.containsRange(Range.between(11, 20)));
		assertFalse(intRange.containsRange(Range.between(9, 20)));

		assertFalse(intRange.containsRange(Range.between(-11, -18)));

	}
