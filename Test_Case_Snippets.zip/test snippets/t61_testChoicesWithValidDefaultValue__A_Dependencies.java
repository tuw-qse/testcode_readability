

    @Test
    public void testChoicesWithValidDefaultValue() {
        Option option = null;
        try {
            option = new Option("choices").choices("a", "b", "c");
            option = option.defaultValue("a");
        } catch (RequiredParametersException e) {
            fail("Exception thrown: " + e.getMessage());
        }

        Assert.assertEquals("a", option.getDefaultValue());
    }
