

    @Test
    public void testChoicesWithValidDefaultValue() throws RequiredParametersException{
        Option option = null;

        Option option = new Option("choices").choices("a", "b", "c");
        option = option.defaultValue("a");

        Assert.assertEquals("a", option.getDefaultValue());
    }
