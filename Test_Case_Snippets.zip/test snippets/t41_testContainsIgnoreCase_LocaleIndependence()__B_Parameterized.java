

    @ParameterizedTest
    @CsvSource({
            "en, true, i, I ",
            "tr, true, i, I ",
            "de, true, i, I ",
            "en, true, I, i ",
            "tr, true, I, i ",
            "de, true, I, i ",
            "en, true, \u03C2, \u03C3 ",
            "tr, true, \u03C2, \u03C3 ",
            "de, true, \u03C2, \u03C3 ",
            "en, true, \u03A3, \u03C2 ",
            "tr, true, \u03A3, \u03C2 ",
            "de, true, \u03A3, \u03C2 ",
            "en, true, \u03A3, \u03C3 ",
            "tr, true, \u03A3, \u03C3 ",
            "de, true, \u03A3, \u03C3 ",
            "en, false, \u00DF, SS",
            "tr, false, \u00DF, SS",
            "de, false, \u00DF, SS"

    })
    public void testContainsIgnoreCase_LocaleIndependence(Locale testLocale, boolean expected, String a, String b) {
        Locale.setDefault(testLocale);
        assertEquals(expected, StringUtils.containsIgnoreCase(a, b));
    }
