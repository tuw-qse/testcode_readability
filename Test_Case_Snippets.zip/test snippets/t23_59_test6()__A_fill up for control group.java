

    @Test
    public void test6() {

        final String input = "a;b; c;\"d;\"\"e\";f; ; ;";
        final StrTokenizer tok = new StrTokenizer(input);
        tok.setDelimiterChar(';');
        tok.setQuoteChar('"');
        tok.setIgnoredMatcher(StrMatcher.trimMatcher());
        tok.setIgnoreEmptyTokens(false);
        // tok.setTreatingEmptyAsNull(true);
        final String[] tokens = tok.getTokenArray();

        final String[] expected = new String[]{"a", "b", " c", "d;\"e", "f", null, null, null};

        int nextCount = 0;
        while (tok.hasNext()) {
            tok.next();
            nextCount++;
        }

        int prevCount = 0;
        while (tok.hasPrevious()) {
            tok.previous();
            prevCount++;
        }

        assertEquals(expected.length, tokens.length, ArrayUtils.toString(tokens));

        assertEquals(nextCount, expected.length, "could not cycle through entire token list"
        		+ " using the 'hasNext' and 'next' methods");

        assertEquals(prevCount, expected.length, "could not cycle through entire token list"
        		+ " using the 'hasPrevious' and 'previous' methods");

    }
