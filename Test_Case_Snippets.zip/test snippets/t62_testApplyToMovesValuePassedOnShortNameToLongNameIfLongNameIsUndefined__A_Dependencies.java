

    @Test
    public void testApplyToMovesValuePassedOnShortNameToLongNameIfLongNameIsUndefined() {
        ParameterTool parameter = ParameterTool.fromArgs(new String[] {"--b", "value"});
        RequiredParameters required = new RequiredParameters();

        try {
            required.add(new Option("berlin").alt("b"));
            parameter = required.applyTo(parameter);
            Assert.assertEquals("value", parameter.data.get("berlin"));
            Assert.assertEquals("value", parameter.data.get("b"));
        } catch (RequiredParametersException e) {
            fail("Exception thrown " + e.getMessage());
        }
    }
