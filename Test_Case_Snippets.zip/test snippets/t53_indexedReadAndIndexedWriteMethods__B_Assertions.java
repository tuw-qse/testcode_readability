

    @Test
    public void indexedReadAndIndexedWriteMethods() throws IntrospectionException {
        @SuppressWarnings("unused")
        class C {
            // indexed read method
            public String getFoos(int i) { return null; }
            // indexed write method
            public void setFoos(int i, String foo) { }
        }

        BeanInfo bi = Introspector.getBeanInfo(C.class);
        BeanInfo ebi = new ExtendedBeanInfo(Introspector.getBeanInfo(C.class));

        assertFalse(hasReadMethodForProperty(bi, "foos"));
        assertTrue(hasIndexedReadMethodForProperty(bi, "foos"));
        assertFalse(hasWriteMethodForProperty(bi, "foos"));
        assertTrue(hasIndexedWriteMethodForProperty(bi, "foos"));

        assertFalse(hasReadMethodForProperty(ebi, "foos"));
        assertTrue(hasIndexedReadMethodForProperty(ebi, "foos"));
        assertFalse(hasWriteMethodForProperty(ebi, "foos"));
        assertTrue(hasIndexedWriteMethodForProperty(ebi, "foos"));
    }
