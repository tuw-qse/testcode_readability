

    @Test
    public void testAllNullBooleans() {
        BooleanColumnSummary summary = summarize(null, null, null, null);
        Assert.assertEquals(4, summary.getTotalCount());
        Assert.assertEquals(4, summary.getNullCount());
        Assert.assertEquals(0, summary.getNonNullCount());
        Assert.assertEquals(0, summary.getTrueCount());
        Assert.assertEquals(0, summary.getFalseCount());
    }
