

	@Test
	public void testAbs() {
		Fraction f1 = Fraction.getFraction(50, 75);
		f1 = f1.abs();
		assertEquals(50, f1.getNumerator());
		assertEquals(75, f1.getDenominator());

		Fraction f2 = Fraction.getFraction(-50, 75);
		f2 = f2.abs();
		assertEquals(50, f2.getNumerator());
		assertEquals(75, f2.getDenominator());

		Fraction f3 = Fraction.getFraction(Integer.MAX_VALUE, 1);
		f3 = f3.abs();
		assertEquals(Integer.MAX_VALUE, f3.getNumerator());
		assertEquals(1, f3.getDenominator());

		Fraction f4 = Fraction.getFraction(Integer.MAX_VALUE, -1);
		f4 = f4.abs();
		assertEquals(Integer.MAX_VALUE, f3.getNumerator());
		assertEquals(1, f3.getDenominator());

		assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, 1).abs());
	}
