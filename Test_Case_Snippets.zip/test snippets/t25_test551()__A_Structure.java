

	public static boolean debug = false;

    @Test
    public void test551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test551");
        org.apache.commons.lang3.time.StopWatch stopWatch1 = new org.apache.commons.lang3.time.StopWatch("");
        stopWatch1.reset();
        stopWatch1.reset();
        boolean boolean4 = stopWatch1.isSuspended();
        java.lang.String str5 = stopWatch1.toString();
        boolean boolean6 = stopWatch1.isSuspended();
        stopWatch1.start();
        stopWatch1.stop();
        boolean boolean9 = stopWatch1.isStarted();
        long long10 = stopWatch1.getStartTime();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "00:00:00.000" + "'", str5, "00:00:00.000");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1592683830012L + "'", long10 == 1592683830012L);  // flaky
    }
