

    private static final int SMALL_SIZE = 3;
    private static final int BIG_SIZE = 1748;

    private static final Integer ONE = Integer.valueOf(1);
    private static final Integer TWO = Integer.valueOf(2);
    private static final Integer THREE = Integer.valueOf(3);
    private static final Integer FOUR = Integer.valueOf(4);
    private static final Integer FIVE = Integer.valueOf(5);

    @Test
    public void testCapacity() {
        RingBuffer<Integer> ringBuffer = new RingBuffer<>(SMALL_SIZE);
        assertEquals(SMALL_SIZE, ringBuffer.capacity());

        ringBuffer = new RingBuffer<>(BIG_SIZE);
        assertEquals(BIG_SIZE, ringBuffer.capacity());
    }

    @Test
    public void testSize_fromEmptyToFull() {
        RingBuffer<Integer> ringBuffer = new RingBuffer<>(SMALL_SIZE);
        assertEquals(0, ringBuffer.size());

        ringBuffer.enqueue(ONE);
        assertEquals(1, ringBuffer.size());

        ringBuffer.enqueue(TWO);
        assertEquals(2, ringBuffer.size());

        ringBuffer.enqueue(THREE);
        assertEquals(3, ringBuffer.size());
    }
