

    @Test
    public void test6() {

        final String input = "a;b; c;\"d;\"\"e\";f; ; ;";
        final StrTokenizer tok = new StrTokenizer(input);
        tok.setDelimiterChar(';');
        tok.setQuoteChar('"');
        tok.setIgnoredMatcher(StrMatcher.trimMatcher());
        tok.setIgnoreEmptyTokens(false);

        assertTrue(tok.hasNext());

        assertEquals("a", tok.next());
        assertEquals("b", tok.next());
        assertEquals("c", tok.next());
        assertEquals("d;\"e", tok.next());
        assertEquals("f", tok.next());
        assertEquals("", tok.next());
        assertEquals("", tok.next());
        assertEquals("", tok.next());

        assertFalse(tok.hasNext());
        assertTrue(tok.hasPrevious());

        assertEquals("", tok.previous());
        assertEquals("", tok.previous());
        assertEquals("", tok.previous());
        assertEquals("f", tok.previous());
        assertEquals("d;\"e", tok.previous());
        assertEquals("c", tok.previous());
        assertEquals("b", tok.previous());
        assertEquals("a", tok.previous());

        assertFalse(tok.hasPrevious());
    }
