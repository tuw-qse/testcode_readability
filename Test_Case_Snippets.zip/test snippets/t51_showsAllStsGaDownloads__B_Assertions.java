

    @Test
    public void showsAllStsGaDownloads() throws Exception {
        MvcResult mvcResult = mockMvc.perform(get("/tools/sts/all"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith("text/html"))
                .andReturn();

        Document document = Jsoup.parse(mvcResult.getResponse().getContentAsString());
        assertEquals("Spring Tool Suite Downloads", document.select("h1").text());
        assertTrue(document.select(".ga--release h2.tool-versions--version").text().contains("STS"));
        assertTrue(document.select(".ga--release h2.tool-versions--version").text().contains("RELEASE"));
        assertTrue(document.select(".platform h3").text().contains("Windows"));

        assertTrue(document.select(".ga--release .item--dropdown a").attr("href").contains("http:/download.springsource.com/release/STS/"));
        assertTrue(document.select(".ga--release .item--dropdown a").attr("href").contains("spring-tool-suite"));
        assertTrue(document.select(".ga--release .item--dropdown a").attr("href").contains("win32-installer.exe"));
    }
