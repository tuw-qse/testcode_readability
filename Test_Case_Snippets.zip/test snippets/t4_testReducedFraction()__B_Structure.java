

    @Test
	public void testReducedFraction() {
		Fraction f = Fraction.getFraction(1.0d / 1.0d);
		Fraction f2 = Fraction.getReducedFraction(1, 1);
		assertEquals(f2.getNumerator(), f.getNumerator());
		assertEquals(f2.getDenominator(), f.getDenominator());

		f = Fraction.getFraction(10000.0d / 1.0d);
		f2 = Fraction.getReducedFraction(10000, 1);
		assertEquals(f2.getNumerator(), f.getNumerator());
		assertEquals(f2.getDenominator(), f.getDenominator());
		
		f = Fraction.getFraction(1.0d / 10000.0d);
		f2 = Fraction.getReducedFraction(1, 10000);
		assertEquals(f2.getNumerator(), f.getNumerator());
		assertEquals(f2.getDenominator(), f.getDenominator());
		
		f = Fraction.getFraction(10000.0d / 10000.0d);
		f2 = Fraction.getReducedFraction(10000, 10000);
		assertEquals(f2.getNumerator(), f.getNumerator());
		assertEquals(f2.getDenominator(), f.getDenominator());
		
		f = Fraction.getFraction(5000.0d / 5000.0d);
		f2 = Fraction.getReducedFraction(5000, 5000);
		assertEquals(f2.getNumerator(), f.getNumerator());
		assertEquals(f2.getDenominator(), f.getDenominator());
	}	
