

	@Test
	@Timeout(4000)
	public void test303() throws Throwable {
		boolean boolean0 = StringUtils.isAlpha((CharSequence) null);
		assertFalse(boolean0);

		String[] stringArray0 = StringUtils.split(", '");
		assertNotNull(stringArray0);

		Stack<Object> stack0 = new Stack<Object>();
		assertEquals(0, stack0.size());
		assertTrue(stack0.isEmpty());
		assertTrue(stack0.empty());
		assertEquals("[]", stack0.toString());
		assertEquals(10, stack0.capacity());
		assertNotNull(stack0);

		// Undeclared exception!
		try {
			stack0.listIterator(2791);
			fail("Expecting exception: IndexOutOfBoundsException");

		} catch (IndexOutOfBoundsException e) {
			//
			// Index: 2791
			//
			verifyException("java.util.Vector", e);
		}
	}
