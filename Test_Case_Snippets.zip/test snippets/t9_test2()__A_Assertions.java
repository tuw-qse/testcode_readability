

	@Test
	@Timeout(4000)
	public void test2() throws Throwable {
		CallableBackgroundInitializer<String> callableBackgroundInitializer0 = null;
		try {
			callableBackgroundInitializer0 = new CallableBackgroundInitializer<String>((Callable<String>) null,
					(ExecutorService) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// Callable must not be null!
			//
			verifyException("org.apache.commons.lang3.Validate", e);
		}
	}
