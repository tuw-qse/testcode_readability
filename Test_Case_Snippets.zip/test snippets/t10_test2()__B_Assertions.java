

    @Test
	@Timeout(4000)
	public void test2() throws Throwable {
		CallableBackgroundInitializer<String> callableBackgroundInitializer0 = null;
		// Callable must not be null!
		Exception e = assertThrows(NullPointerException.class, 
				() -> new CallableBackgroundInitializer<String>((Callable<String>) null, (ExecutorService) null));
		verifyException("org.apache.commons.lang3.Validate", e);
	}	
