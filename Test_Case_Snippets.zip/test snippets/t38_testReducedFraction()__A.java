

    private static final int SKIP = 500;

    @Test
    public void testReducedFraction() {
        Fraction f = null;
        Fraction f2 = null;
        // save time by skipping some tests!
        for (int i = 1; i <= 10000; i += SKIP) { // denominator
            for (int j = 1; j <= i; j++) { // numerator
                f = Fraction.getFraction((double) j / (double) i);
                f2 = Fraction.getReducedFraction(j, i);
                assertEquals(f2.getNumerator(), f.getNumerator());
                assertEquals(f2.getDenominator(), f.getDenominator());
            }
        }
    }
